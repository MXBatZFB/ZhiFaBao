package com.zfb.zhifabao.common.factory.model.api.consultation;

import java.util.List;

/**
 * 作者：Maodelong
 * 邮箱：mdl_android@163.com
 */
public class GetProcessDucumentsResult {


    private List<String> filenames;

    public List<String> getFilenames() {
        return filenames;
    }

    public void setFilenames(List<String> filenames) {
        this.filenames = filenames;
    }
}
