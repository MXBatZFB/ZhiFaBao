package com.zfb.zhifabao.common.factory.model.api.consultation;

/**
 * 作者：Maodelong
 * 邮箱：mdl_android@163.com
 */
public class GetLookLawResultModel {
    private String filename;
    private String content;

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
