package com.zfb.zhifabao.flags.contract;


import com.zfb.zhifabao.R;
import com.zfb.zhifabao.common.app.Fragment;


public class MyContractFragment extends Fragment {


    public MyContractFragment() {
    }


    @Override
    protected int getContentLayoutId() {
        return R.layout.fragment_my_contract;
    }

}
