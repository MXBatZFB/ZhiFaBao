package com.zfb.zhifabao.flags.account;

public interface AccountTrigger {
    void triggerView(int flags);
}
