package com.zfb.zhifabao.flags.main;

/**
 * 作者：Maodelong
 * 邮箱：mdl_android@163.com
 */
public interface CommonTrigger {
    void triggerView(int flags);
}
