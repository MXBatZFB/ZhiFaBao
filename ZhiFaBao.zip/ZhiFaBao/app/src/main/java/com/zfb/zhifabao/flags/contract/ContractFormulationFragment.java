package com.zfb.zhifabao.flags.contract;

import com.zfb.zhifabao.R;
import com.zfb.zhifabao.common.app.Fragment;

public class ContractFormulationFragment extends Fragment {
    public ContractFormulationFragment() {
    }


    @Override
    protected int getContentLayoutId() {
        return R.layout.fragment_contract_formulation;
    }

}
